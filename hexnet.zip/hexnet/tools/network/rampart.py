import socket
import threading
import time
import os
import winsound

f=2000
d=5000

def title(message):
    print(message)

def warning(message):
    print(f"Warning: {message}")

def ramconfig(port, message, sound, log, logname):
    try:
        # Create a TCP server
        tcpserver = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        tcpserver.bind(("", port))
        tcpserver.listen(5)

        print(f"\n  RAMPART ACTIVATED ON PORT {port} ({time.strftime('%Y-%m-%d %H:%M:%S')})\n")

        if log.lower() == "y":
            try:
                with open(logname, "a") as logf:
                    logf.write(f"#################### HeXNet RamPart log\n")
                    logf.write(f"\n  RAMPART ACTIVATED ON PORT {port} ({time.strftime('%Y-%m-%d %H:%M:%S')})\n")
            except FileNotFoundError:
                print("\n Saving log error: No such file or directory.\n")

        while True:
            # Accept incoming connections
            socket_client, addr = tcpserver.accept()
            time.sleep(1)  # To mitigate possible DoS attacks

            def handle_client(sock):
                remote_ip, remote_port = addr
                print(f"\n  INTRUSION ATTEMPT DETECTED! from {remote_ip}:{remote_port} ({time.strftime('%Y-%m-%d %H:%M:%S')})")
                print(" -----------------------------")
                reciv = sock.recv(1000).decode()
                print(reciv)
                if sound == "y":
                    winsound.Beep(f,d)  # Beep sound

                if log.lower() == "y":
                    try:
                        with open(logname, "a") as logf:
                            logf.write(f"\n  INTRUSION ATTEMPT DETECTED! from {remote_ip}:{remote_port} ({time.strftime('%Y-%m-%d %H:%M:%S')})\n")
                            logf.write(" -----------------------------\n")
                            logf.write(reciv)
                    except FileNotFoundError:
                        print("\n Saving log error: No such file or directory.\n")

                time.sleep(2)  # Sticky honeypot
                sock.sendall(message.encode())
                sock.close()

            threading.Thread(target=handle_client, args=(socket_client,)).start()

    except PermissionError:
        print("\n Error: Rampart requires root privileges.\n")
    except OSError as e:
        if e.errno == 98:  # Address already in use
            print("\n Error: Port in use.\n")
        else:
            print(f"\n Unknown error: {e}\n")

def main():
    
    print("\n// RAMPART //\n")

    print(" _____________________  _________________________________ ")
    print(" ___  __ \__    |__   |/  /__  __ \__    |__  __ \__  __/ ")
    print(" __  /_/ /_  /| |_  /|_/ /__  /_/ /_  /| |_  /_/ /_  /    ")
    print(" _  _, _/_  ___ |  /  / / _  ____/_  ___ |  _, _/_  /     ")
    print(" /_/ |_| /_/  |_/_/  /_/  /_/     /_/  |_/_/ |_| /_/      ")
    print("                                                          ")
    
    
    

    warning("You must run HexNet with root privileges.\n")
    print(" Select option.\n")
    
    print("Manual Configuration [Advanced Users, more options](y/n) \n")
    configuration = input("   -> ").strip()

    
    if configuration == "y":
        port = input("\n Insert port to Open.\n\n   -> ").strip()
        message = input("\n Insert false message to show.\n\n   -> ").strip()
        log = input("\n Save a log with intrusions?\n\n (y/n)   -> ").strip()
        logname = ""
        if log.lower() == "y":
            logname = input("\n Log file name? (incremental)\n\nDefault: *\hexnet\tools\network\log.txt \n\n   -> ").strip()
            if not logname:
                logname = os.path.join(os.path.dirname(__file__), "../../other/log_honeypot.txt")
        sound = input("\n Activate beep() sound when intrusion?\n\n (y/n)   -> ").strip()
        
        ramconfig(int(port), message, sound, log, logname)
    else:
        print("\nInvalid option.\n")

if __name__ == "__main__":
    main()
